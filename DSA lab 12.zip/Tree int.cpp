#include <iostream>
using namespace std;

class node {
	public:
		int data;
		node *left;
		node *right;
		node (int val)
		{
			data = val;
			left = NULL;
			right = NULL;
		}
};
class Binarytree {
	public:
		node *root;
		Binarytree()
		{
			root = NULL;
		}

void PreOrder(node *temp)
{
	if (temp != NULL)
	{
		cout<<"  "<<temp -> data;
		PreOrder(temp->left);
		PreOrder(temp->right);
	}
}
void InOrder (node *temp)
{
	if (temp != NULL)
	{
		InOrder(temp->left);
		cout<<"  "<<temp -> data;
		InOrder(temp->right);	
	}
}
void PostOrder(node * temp)
{
	if (temp != NULL)
	{
		PostOrder(temp->left);
		PostOrder(temp->right);
		cout<<"  "<<temp -> data;
	}
}
void display()
{
	cout << "PreOrder: ";
	PreOrder(root);
	cout<<endl;
	
	cout << "InOrder: ";
	InOrder(root);
	cout<<endl;
	
	cout << "PostOrder: ";
	PostOrder(root);
	cout<<endl;
}
};
int main()
{
	Binarytree tree;
	
	tree.root = new node(1);
	tree.root->left = new node(2);
	tree.root->right = new node(3);
	tree.root->left->left = new node(4);
	tree.root->right->right = new node(5);
	
	tree.display();
    return 0;
}
