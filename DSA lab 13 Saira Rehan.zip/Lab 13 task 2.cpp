#include <iostream>
using namespace std;

class Node {
public:
    int empNumber;
    string name;
    double salary;
    Node* left;
    Node* right;

    Node(int empNum, string empName, double empSalary) {
        empNumber = empNum;
        name = empName;
        salary = empSalary;
        left = NULL;
        right = NULL;
    }
};

class BST {
public:
    Node* root;

    BST() {
        root = NULL;
    }

    // Insert a new employee into the BST
    void insert(Node*& temp, int empNum, string empName, double empSalary) {
        if (temp == NULL) {
            temp = new Node(empNum, empName, empSalary);
        } else if (empNum < temp->empNumber) {
            insert(temp->left, empNum, empName, empSalary);
        } else {
            insert(temp->right, empNum, empName, empSalary);
        }
    }

    // Search for an employee by employee number
    Node* search(Node* temp, int empNum) {
        if (temp == NULL || temp->empNumber == empNum) {
            return temp;
        }
        if (empNum < temp->empNumber) {
            return search(temp->left, empNum);
        }
        return search(temp->right, empNum);
    }

    // Delete an employee by employee number
    Node* deleteNode(Node* temp, int empNum) {
        if (temp == NULL) return temp;

        if (empNum < temp->empNumber) {
            temp->left = deleteNode(temp->left, empNum);
        } else if (empNum > temp->empNumber) {
            temp->right = deleteNode(temp->right, empNum);
        } else {
            // Node with only one child or no child
            if (temp->left == NULL) {
                Node* rightChild = temp->right;
                delete temp;
                return rightChild;
            } else if (temp->right == NULL) {
                Node* leftChild = temp->left;
                delete temp;
                return leftChild;
            }

            // Node with two children
            Node* minNode = findMin(temp->right);
            temp->empNumber = minNode->empNumber;
            temp->name = minNode->name;
            temp->salary = minNode->salary;
            temp->right = deleteNode(temp->right, minNode->empNumber);
        }
        return temp;
    }

    // Helper function to find the minimum value node
    Node* findMin(Node* temp) {
        while (temp && temp->left != NULL) {
            temp = temp->left;
        }
        return temp;
    }

    // In-order traversal
    void inorder(Node* ptr) {
        if (ptr != NULL) {
            inorder(ptr->left);
            displayNode(ptr);
            inorder(ptr->right);
        }
    }

    // Pre-order traversal
    void preorder(Node* ptr) {
        if (ptr != NULL) {
            displayNode(ptr);
            preorder(ptr->left);
            preorder(ptr->right);
        }
    }

    // Post-order traversal
    void postorder(Node* ptr) {
        if (ptr != NULL) {
            postorder(ptr->left);
            postorder(ptr->right);
            displayNode(ptr);
        }
    }

    // Display an employee's data
    void displayNode(Node* node) {
        cout << "Employee Number: " << node->empNumber
             << ", Name: " << node->name
             << ", Salary: Rs" << node->salary << endl;
    }
};

int main() {
    BST b;

    // Insert sample employees
    b.insert(b.root, 101, "Ayesha", 50000);
    b.insert(b.root, 102, "Amna", 60000);
    b.insert(b.root, 103, "Zahra", 55000);
    b.insert(b.root, 104, "Hamna", 62000);

    // Display employees in post-order, pre-order, and in-order
    cout << "\nPost-order traversal of all employees:" << endl;
    b.postorder(b.root);

    cout << "\nPre-order traversal of all employees:" << endl;
    b.preorder(b.root);

    cout << "\nIn-order traversal of all employees:" << endl;
    b.inorder(b.root);

    // Search for an employee
    int searchEmpNum;
    cout << "\nEnter employee number to search: ";
    cin >> searchEmpNum;
    Node* emp = b.search(b.root, searchEmpNum);
    if (emp != NULL) {
        cout << "Employee found: ";
        b.displayNode(emp);
    } else {
        cout << "Employee not found." << endl;
    }

    // Delete an employee
    int deleteEmpNum;
    cout << "\nEnter employee number to delete: ";
    cin >> deleteEmpNum;
    b.root = b.deleteNode(b.root, deleteEmpNum);

    // Display in-order traversal after deletion
    cout << "\nIn-order traversal after deletion:" << endl;
    b.inorder(b.root);

    return 0;
}

